A python package to join multiple strings.

Instructions

#
1- pip install mdodata

2-from mdodata.mdodata import concat

3- concat('Hello', 'world', sep='.')
