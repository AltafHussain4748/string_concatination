def concat(*args, sep="/"):
    return sep.join(args)
